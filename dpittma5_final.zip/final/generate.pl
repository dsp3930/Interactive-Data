#!/usr/bin/perl
#
# Author: David Pitttman
# Version: 2
# Date: May 5, 2023
# Notes: Original base CGI code by ChatGPT query.
##########################
use CGI;
use Time::Local;
use Data::GUID;

# Generate a new GUID
my $guid = Data::GUID->new();
$id = $guid->as_string();

# create new CGI object
my $cgi = CGI->new;

# set content type
print $cgi->header('text/html');

# Base64 encoded image for embedding into webpage
my $ediImage = "iVBORw0KGgoAAAANSUhEUgAAAMQAAABbCAIAAACj9L2qAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAABymSURBVHhe7Z13VFtXnsf3r92zZ3Z2dmdndqdlSjKTTKrtxC3uxlQDBptiMBB3gmucuMUYY8BU0216r6KIIqqQECAhCQkQ6hK92Rh3O9jJ39mfdB/P4iFhNWP7nPc9n8PR+93fve+K9+W+fvmXn0mRspJIM5GymkgzkbKaSDORsppIM5GymkgzkbKaSDORsppIM5GymkgzkbKaSDORsppIM5GymkgzkbKaDJpJ1DfVEZPXfiXtLaUzqUwsv4d9GVLLIv1mkgw/qfpoW/G//umtpt4hQDY2h30lUq9e+s3U16Uq+8W7pf/257cayu9XiGWz2Fci9eplwEwdivJfvlf27395q6n8/YoB6R3sK5F69TJgpk4F5T//TvnF3wC6/7cCGv8totFuH+p59R9XikkzLaMMmUlZ+at/VP7Hu0D7uTgs+pao1fsk6jn1T6vEUnI3t3zSb6b+TmXVf39Q9cv3ANb561j0LRF97ynU89p3viDNtJwyaCbqr/9J/dU/gI7z8Vh0ocTK+31s5TwqifohVjCvAemsToLV0bNGJNbxMPqeINapiPagUInqARYl9eplwExdytrffFj7X+8DnRf0mElYza5/d23tbz7Cafxwq6hTgRX//LOguLX+nc91E6xOwz8397Nk2Pp0JBt/Lp38EVsgtYwyaKb6335c/+sPgK6LCVhUR737z/Lf/5JA35VUrBjc5nOCUPoq6LuchK2P1Bsg/WYSdalo//cJ7X8+BNjfJ2JRHakTi8Y3uYxvfMHY5l1KCgMrhoToLEKC9dnsqihrw9a3SNKJ59gnUsslg2Zq/N2njb/9COBc0mMm+fjcaAVz6kbZtJapm+WjDVyZzs5FNvrDWBkdT7A6sMYRGle20DFgILHsrpDSzj4TxbD346dXYwWklkUGzMRWNf9hRfP/fgx0X3rTdyVwJC5q7eNeTWM572/56xrUbaDdeT9KeIsknfxpYGSuX/1UKH8kkD7skTwQyB72KZ9AEMt4g6XfTANsVcsfV7b87lOAG5yMRd9I8UJS2z61QV0lwNW3gzZDkvHnrK6p2goptVxsJN1CEy6WwukCr/8eJb/v+nd1Fz2zT9okBa6PObAiPOCjUP+Pruz/LPzImqiTOxJD/ArSIuhNTYOioR+wmmapR3w/N6Ez7kxNSEBhsG9+RCAlP5kN3sWKLZAhM6np76yi//4zgHv5jTYTc7UT6ieBtj+s6K/lYkkWiCu6F+xfsO+Tq74fXjGe8K/Lsfovk3js2Y3w1gOrIwktGGLfR6HHbZMzY1lCmZmbv6FeTWgTOLs700KPggyaqe0vXzD+uBLghaRg0TdSfVUdzPc3oK7qwvxkm+V3eWFMuuhfsPfTq6ZycGOskTum+jql72fhhOrGEGiTVFUuht0i1pDRotHUhKYAn0/DoCdYhrkyYCaOmvnX1e3vrAL4IS9O+HUlHZsbkM6+FmTjz7BOaCWIzWf+aSXqLQ7HI8jyq03Mrknf1ZHeK8NNxW9dNG/gPtbKkirKERDqGg/0LS223dTzVlrDIKEdRH46D8swV/rNJOaoWe+uYf35c6Dnyg0sqqM+uqhhlUPdn79Yftr2n5eOvhiQBxjizlV2qKu6COMKsAwLVF0l9Vp9zQz8Nsf1qp5grSypojwhoa5JeK+NykxhY20ZJ1rjIKERRPaNbizDXBk0U+d76zr/uhoQhOoxk+DQBc67a5cfXsC3Up27KANtYvYXDqifC3hv3QBTgiVZoIoKiee6KDMIOVWFNfEyFeb3Euqais+mOFrTENacEYJkQguI7DRLDzENmWmw6x/r2X9bAwiv3sSiOlKGpQ2vd1pm1MevyIYeYz2ATrZLOKsdUScBzlqn3pQyzsdbNJ/Xu0gHrXB6UlEp9dgQQ8BzU+y5wNLLp6v1EnKGmpbUZeSwBCos6CO0j8i4yWVypjoFM+3cW1U1iqjLjT42CYQcnBN++cZfO6hvHiJUR2S9qt1c9yDn/S85760FesPSsKiO5EOPJ9Mrboem3L6SvDxMJxTIR55iq9c4Scpd7Yh6CHSvcYI/AIgP1LB52z374gtRmoWqqJLt3hJHwHN7PIt3G8uwWAVFfYT2gT1br8MmxzLm1Sm4c8w/n5CJgPwKqp7blHpV3zJMqI7IyuRjGeZKv5kk3YPcf27g/n0d0Buux0yvV2KmhL/WCXUP4K13BvdjZVYVpVrmvj2ewB7bxHa+9cxU3E9oH9htk1DXMoxl6Igvf3hobw4hGXH+DNXIE4761mFCXURmVg+WYa4Mmon34SbsZmp4OhZ9MwRO6lm3E7/X27PBVcpRY2XWFoUqd7NLJLDbIbm9ZwbLsFj5JSJC+xrsk+paR7CMhaqoU7jbJxHz7RJ9d6f3KIzas0PLhLqIzBwBlmGuDJlpqOfjzT0fbAD6IzKw6BsgCUMs2OCCOgYIN7tL2CqsbKH6J39MGX4stOzqQHmNYpdjMgE351RKnYLePa2XNu6tgbEFVy6WVn7ZwML2UzQ/nVLq6PrNJBl/HrAvF0vDfmpwdUxu6hjHkpYUtIzX0oI1kpEnxDLMlQEzcYcEn2wRfrgREF17U8wkYUp6N+5CvQJ6t+6RdOm5zpY//PiM8u5W8fTHognuhGVmqlW4ON8wkdSCChNOJPPKxYtauOHqcqO2bRTLWKSQ8BZCPqKwyqjDJmiZUBGRnt+LZZgr/WaScod6P9vW99FmYCAyE4u+VknaJf0bd6EuadjmIWHrv2IbIJ75c88I8IlwzEIzldUrnd3STOW74AasvhHKo0gI1QEX97RahkEzpeYKCPkIiGMZS6qWMUaoiEgv7MMyzJVBM/Wv2N7/yRZAHJWFRV+fpCypaLMb6o8GGy+9YxJSgOjWX7qHgE95I1zLnmoqo6l27kk3lf3Hjb0xB8qtlBCqa/DIqGWOYRmLlFshJuZrScg06tweWiZURKQVvTIziVbZDHy2DXjtZpJ2yAc2u6POaNjhLTUwJiHt753+W6cKWMEe4o5bZKbSBpWjd6apHP2OitU3QrlVUkJ1wMk7q6bdsJn0VQHis406t69pHydURKSV9GMZ5kq/mWS8YfHntpIV2wFpdDYWNU7ScobU77T0cpJsUP8D/yYJxiTptj2oJxps9y7tJNB+weR7TAWwskPFs9BMjWoH32xTScgz4bQop1pGqA447supYRk8mk4t6SfkI1KKjHIDtEyoiLhZKsIyzJVBM0lX28lW2QDSmBwsaoRkhU3SdU6oouzweQsvQ8s6ZFIbT6w1wNZbxtF/7qarg7yJv7fKgFUMhaVmahq0D8hdRN6B8zVHLtUv5tiVxsTCXpEpZ3M5NfJF7ec6BOTVGD41C73RRchHFNBe/ssB1XRMECoibpYPYBnmyqCZ5Gvs5Z/bArJYY80kL2qSr3dCtTAOn9e9AWKSZB1y+Q6vF03Z75UZdz3pYPfY+41i4ItWGW/MIjOVNA/aHigg4HCosK13Vjr5oz5MfiAku1ZBaB+wO1hA7ZjAMhZKMvmj3zkqIR+AKk38W1jSkqJ2ThDqIm5QxFiGuTJoJsVaR+UXdoA8NheLLilFcYty/U5URRfF4QuyYWNvVOGSdyoUtt4vGrHbKzP6GvehrtEP6kTA6kYJz5RBYrFKWod2HC4iYH+0mNF/F8uwWNl1CkL7gO2RItjkWMZC1bAn7Y4WE/IB99MVPWqjfs/UrklCXURqpaW3xvWbSc4fVq13Uq+xBxRxeVjUsBRFLer1zihfg+sB9fqd+KLy6PcmjU/yTrnK1huvrrL3kfP1X8HTq8Mdwx9W9wFr6wYsNFMxfdjm6xICtsdKrWimLJqS0L6GoJLqrkksQ0e9I3NfXW0kJmv5JpGFJb1MVPYkoS4itVqKZZgrQ2YaGfxy5+BaR0B5PR+L6hOM7Yri1sEvnVEyoDr4nVz1UJlTuyBotJ/kHfJBex+8otrJT87Tc5dqCR1hDn1EEQDrqH2WmqltePvxMgI7TpYzRNYzU4OK0L6GE2XV7CksY15sxaPAOAYxU4vNiXIKy+DZH0HQMqE6IsXoW8WGZNBMQxtd0IMfqiXNpCyhD89nap4SOXRWpsSeMAQ/6RYNHbssf9nxuKJDPuTo+6LKTn8F14QndZCO0tUfl/CB9RVC3qhFZipijGw9RSGw/TTlbGZ3aFHvEuTTjf0DyGxUE9rXUh5XIW4UzjDE91pFd0tZYyH5gp0XqIvSMA7EtA0YfapRzZkmVEek1MixDHOl30wK/sjIJtfRL3cC6niDjywqS1pHNu1CacDg4fMyxYKZ/1S5daM6CcPHQ+QGJggAKTrlIzv98OQR16/kZj0LENii+rSAC2wo7bHUTMzRLd9WmoFLSL2R53SZzYOEuqZie6Gm3rhDb6Rq7jShBURy3Yu3+82TATP1jIxt2TW20RlQJ+g3k6qUPr7VHeUAI0cvyBR6nnpW59aNbXHD04ZPXtE7PoGTRp398bRRtwMKrplPlXzdqPgslw1sLOLxLTNTccfY5nPVZrD1ArWlfxZrZUlltAwS6prE1ovUlIaXXHgjqIo7TWgEkUQzrZ3FMmSmUTDKxCZXYDBRz4Nm6tLWCRsPlACMBF7U6ySkwbz6ifnWgNHTVwnjk7JLOe4SgCeMuR8020mgIJp8ZWYnsCmvm2/Zu4sNfXc2f1+z6aLpfF9TIzBqtChjT24k1DWabcF18fUKiYlPRtQJbkP3CE0BSSaacrEMmmly++6pLW7AUFIRFp3XYBl9aocnKp2CAezrS3LlUjPXyCZ/HMynTdl4zFdxGzt1FR+fwEmTLgF40cSeI0oLnAQ6Viv9/CYL2JLNttBMsKvam9S+4XKdqWwNpTGkRs3mIxye80xkEqobg2ssvYQzacaVLY7qyfawBkJrQGKTUdc8l5B+Myl7Rqdt9tza5g4MJxVjUa3ASdN23qgImAAnGTEHEvhpKJ82vcMTrzj2TRj4SclWTrvtx4OTHpY6CXScKv4imQFsTe+00Eyg5oF77onML6/STCCUFpTHN37AaJc/DMzjbQ5rILZjANd4RnS9nG/BO5NhNZINi1aX2GzpM4YGzCQYvWXreXv7bmAk+YWZwEm3HPaiODAZFLzEATVBGj8V0G7beelWv+V+EF+85XFUafq522KdqBxYHU8HtqWyLDcTSDj6rLh7Kq5JHUVTvJToBmVe13i/iZckpJM/MuUP05jD5ytEX2VxXVNYO+JaN0c1b4hs2hTZbBPbuiu5/WAuN6xOWiWY6Ru19EvB6ur67sQ2qUKoUiC6UdNnGLGwYnNl0Ewzdl53duwBRlNKUHCIwrjj6IOCwDQ4ycR52cBPw4UNM3beeCM4tz2PKnlWcBLoJEW0NqYFsEli8IetYKZllnTqJ9i9CkfmekbmYPjhD/8AboYIxLGMN1WGzDQ26+B919YTGEsthchwBeOuky+KALfgJN+sGf7ATyOFjbMOe/GmgBmvoyqda9yi8WdhdTK/rO59mRwz2HGdvu5aIwAfYEtgjZJ69dJvJpVg7K6jzz17L2D8RtlIRfs9J1+0CNyG03uj926LBX4aLW6654g1OOsVCN7FyrTKYY0RdufmYRvTQpppOWXATMKx+zt9Hzh4A3eOnHuwcx/6DMycClVY4CRco+Vtd70DZwMvwLqw0LziaArCiYZ5OEY2C97C3dzbK4Nmeui875GTD4E731y1ipOW1vU6OX7xw/la867IFmNwvNqI1wK2X64vNPp2FSmrSL+Z1MLxR67+j3f6Ak+0P4HZM2GKZZkJOb5GtvlsFaJNbNRcIj2DPwRcZ+C1bC/VFrIMPpBP6hXJoJmeuAU8ddmHc++7CPOOuM1QfLV06zcVCMbAy//NV8/g0/0xbXgVu3PVBUwTHlkhZS0ZMFPv+Jz7/jlXf8T9s9eWYe+GK6FKsu1EGYIheomZeOonB6PoeL79t5VFDNMeWSFlLek3k1J+d877yDO3AODBuWV1EiihQrw9qASxtJn46ieHr7Vs/xpLdjxFKaRb52LVa1eP5EF71yS7Z0Zq2at/yyn9ZgJNUhhPjl+ajUpfZieBEstFO44UIZZ4ppGnenwkrAnPdAwqLWk1yknSyR+7+2apFdKCm9ys+I7cZHZV6QDHlClNkayymQXyR1Vl4ozY9puRjKKsHrYA60ZEUIXvx6EBKyOgnyhiLb06dxo0E0hu2asdZiuptN9ufz6C2affTHzVk6NXGvE0pyPFJc3G3tSjNQwGbIz1XhWhi/+G2LDTVL7EqOPCgdFnwYFlR+1Tvj9UIlSa+caEdOJ5fib/kE2ibjegY9VVGvdcCaKgSFqcsc/jGqOos3XQ7W998rjWe/IY11Jmel1KLu6z989FMPv0PBXEVz0ODKbhOc4HCkqaTLhJWZAvJMxzhfO1V7ZAZy6R/uEfOoUzbeypDv6MSOc238DIXOCeTFSlYdFDlQLlYxbvNr1rsqt3VmLgDxJGx4ybXM9NcfiqcYK1s85dPlWFFlPjWV29d6APXPF9qIWqI2mGWPF9Rvc0s3uaL3tIKEUSKp9AZ6AnqPTMgWLUbIm+t+R61U+hNcjXO3UYfBdop513u8/APeY30kyFvY4+2QhmL9FMPaonX1+oxRNc/PPKjB6TkPKL+tCMRAe9s2EjNbWPRYa17tmRgILR1+iQA/uC5OSufbtueton77FN9LBL2rcrLSaaCfaCUvhdH/bJRfm5Bb2tXZMs7SQ78Fs+/y3Ve2cq5EMtT/ukg3tz8ov7F89hClvFyzEFtRAUUFBdp4RIA2PkanBDpfbx2Utna1EppKE+eDoknz1VyZ5//Ly5Y/yoX56nQ4qHrWZdkPZNEKVZ550WSo0cIt5Oms542SdfC2+B4OnAMtRsUmIndLutexol9ygehYc273VO1baW5O+enprKEc9PRMsZuBcZQfffnQHfCEr3e2Rx9B3L6jcTR3I/9Hp7YjY/OpVdVGPp05ymKiVf6OSZgWAKF5hJoHwSdLYGL93lk1PWYPJTOHmlIlenFODQoSKxduSQTv4UEtaMgnu9s8AxMLrs9cpEEV1CtJtkYHTuwP5CFHFzTt3lcmOfTw7UqqUP45k4u5xTCyuJxz3J6VxU6uWR0aWzx8GfT7r4PQ1vQZeg4+WozxHRDEIRsNcri6O9Mldep4D16hYdPlwMg9OJk5VoEXV7t5tmJjf4Gwg6TsEzcSJimFCq+2VxavXN+KPfTO29sy4e6Tvd04CETCtMzW6SUnMFaNVAu85xMWzgoNNVeJGbV1a56U4C5VDEO3enAweOlYnnx4waxqjzHk3QxTOToTmHep6S25NLwV5yTc7pcfbIgFI3b83MC/D7/SqwFDUCtQDfg4WwH4StEpnYUTr/MPX34S0o5+S5WsI+6LuQRlT0bTANCy3U+dAmvG5ZvSImtQt1AIDuQUJDx8T1NE61didb0TSI9yejWPOS+PX0brTo/VV+bGpXMVXeytUMQsfOUlEcdXu3r+YN26xSEQqevlgLaTVtI54BeSgHSrmyh1gVj/TzVxqzSvqrmof0PuFuwEzCWVe3my4uN4DEdEtn9DVVqdk9aNVA+/zZjUD15NiJCjy+e09GubmToGdXSx18c4CAM5W4mdqEdxz9ciHouC+nkTstm/pJonPWczmR5eSvKXXy17xFCAfgfqcqUCNpZSJa1wRHhh25i3QeNjp1tQnl7P+uGl8RCIafY8E0VHQ5Qf/x9dlrdJSQkK+ZuQCa9Q4qQxHqojktrqV3+5+uRKWx2ukr4CdaPB+94B9fBX5fj+IxWTzodod2b/VNWDMKppaI0ini0NQuz8BSFIFSrvwR+uz8VX7nkteQ9ZuJJbwDw6CrYwqQeJODRZdLN7L4aNUAmvBPoHh8PKgcD3q4pZfXmv9eTlat3PZgIeB3oebFyNQ1aXdIE7Q/XMTomxUMPj0e1Yoiutgf0TzEDH+XPueoKAIVUQugVuGM17fVeDKO/8VaXTOBTsW0oaITkZpDtMU6E8dECdeLNTPdwK7N85tKFKnUmimNKnP6uhRFdInWTpsRky9Ei2fj2zXNzevI1SYUz6l/8ad4KKQRBXWB7+56rAxKuYpHKOIYWNKx5N0tA2YS3HF3SHazTQSSUk2bs9xy3czgoVUDYCZw0omjZXjE0/lGeY1Frwtm0JTbj5UCPldoaBvDUBGczUNBl7PV/SNzydVStOh6tvpKNj++XGR/igKLO05q5l4CM3lfrkcJVM6LtyWPxTNR0C+0EUXQom9oA8FMMSX9qMjxTEWbvoPZ00kdKCGuXHPaBdV3X6hBkYrOccHQD3Yny+GzzYnyU4ms2JL+I1F0VBpZrJkALqqkDy2eSe3StofpUFQrimfpHCEcu451e9e56mNxjNDcnrRaWXXXBE/77CVX+RiV2p2mdEjMMFPPHc3ZzbZ4AE5qsOhyKS2tG60aaGgbPXWkFF/0dkgpt/gt5vQmNXpTzD2skS6619Q3G17ev+1sFQpeLtRM7Qg/0WJwoRA2ZO/InN3FGljcdk5z3g5m8oxoQgkJOmMkFvyusrAdu82McvZGtRDMBAayOVeNSvdENBWyRlmyB60D96KrxCUdmoHnZBoblcZUaaYAgOq7rtBQhMKebBu4hz47XqrlDT6FUrzD17Tmi6QMoMXTGQuOUg4ltqN4SHEvV/2Eo8Sug6Dg4aR2lvQBfLve0WdNvXeqtIdZ3arHqNTmPBU6ifL1ypCZZjy3Xt+zKQ5ISezEosultBsctGrgoHsG/tnHNomivaBnodJahzZeqtGLRxwdtg3kZNCHN2gjWy7XeVxv2xVD3xhcC4ubL9dBqXTqp6MZbKxWcI3NVRrkDEw8P53LR8EdEIlvcwhvRIu+Se2EA3BoIbJaAnVRArApuBat8XC6ZldwPJuL4tG1mmEYGneNakGR8u6p/tFndmEN8BmqOEc1w9q3h9JQaYw2PwIa1y6ezF0wA9jFkj4Uh4o7Qml24diMie6xdBSHdtxi6c5RLZsu1zpFNkMRmAkVbb1Sz5IvdTtEv5k6+DNeG2M910cDqfHWvAJrjNJTOGjVuvhsja+weJoOpDY4PUlgrA9v0GXTtaZjhYIuFXY5u2907pvS3o3XmnRztka1hGs3FYjaO2Mb24oX+WVyxJPPOxSPvG924kGEY3xbEUfPlCbiyR/jGlW2cS8aAWCNSa2aC7AhVAmKRDZozg3BfH4ZbBQp42kGjEL2hF0sHUUQGyIaIadTO9ikMUdQ8Hjxgjl06ZL7OxOYeBXnRM3JP6hN+gDqfhnRiBdBa/AbgCIYpdA33RzZzFKYY6bb3uujvdZEAslRDNHQD8vJjesstGoc342xlRTrOAmpZ3iuQjiTxBi+1qSMalZndU0wFQ8JLydJJp43S+6nto9ENqliWtTZ7InOeashdaofp3eMRbeob7JGu7XjGah/7FlV752EtiGoFU8fKuXfWvrRYahYyJ2KblaHNsjjWgcbBu6ibvSOPSvh34Ii3N/dg09gsZg/LZh/TZk79DSfMwl9g6+QwhypE90VzV9wB6dWCGagtHXR63u8oac57AnodjJjuGN+NweCwa+2fzZJ2/OktuG6/lmIoCKG4lF+9xRFOCNa+P+0CDJgJt5tn9XX0H+O8lsXfWDL9eXEf30M/n+rNB1YG11lVSeRekUyYCbu7X0rI3w0/9PuNeP/+bXKUkunxyO1PNJvpl7l44NronT/7eZr4asV4VWkk94e6TcTqKlBHXG4NMQv/zVCLbN0lkVSyymDZiJFylSRZiJlNZFmImU1kWYiZTWRZiJlNZFmImU1kWYiZTWRZiJlNZFmImU1kWYiZTWRZiJlNZFmImUl/fzz/wOn/LtLvt7RMAAAAABJRU5ErkJggg==";
# print HTML header
print "<html><head><title>EDI Archive Graphical Volume Viewer</title></head><body>\n";
print "<img src=\"data:image/png;base64,$ediImage\">\n";
print "<hr>\n";

# check if form has been submitted
if ($cgi->param()) {
  # retrieve form data
  my $sender = $cgi->param('sender');
  my $receiver = $cgi->param('receiver');
  my $doctype = $cgi->param('doctype');
  #my $uom = $cgi->param('uom');
  my $date = $cgi->param('date');
  my $chart = $cgi->param('chart');

  $sndr = $sender;
  $rcvr = $receiver;
  $doc = $doctype;

  $sndr =~ s/.*\,//g;
  $rcvr =~ s/.*\,//g;
  $doc =~ s/\,/ /g;

  # print form data
  print "<p>Sender: $sndr</p>\n";
  print "<p>Receiver: $rcvr</p>\n";
  print "<p>DocType: $doc</p>\n";
  #  print "<p>Unit of Measure: $uom</p>\n";
  print "<p>Date: $date</p>\n";
  print "<p>Chart Type: $chart</p>\n";
  print "<hr>\n";
  #my $one_week_ago = one_week_ago($date);
  #print "<p>One Week Ago Date: $one_week_ago</p>\n";

#Generate regex for archive query
my @tmp = split(/\,/,$sender);
$sndr = $tmp[0];
my @tmp = split(/\,/,$receiver);
$rcvr = $tmp[0];
my @tmp = split(/\,/,$doctype);
$doc = $tmp[0];
if ($sndr eq "Any") {$sndr=".*";}
if ($rcvr eq "Any") {$rcvr=".*";}
if ($doc eq "Any") {$doc=".*";}

#print "<br>$sndr\n";
#print "<br>$rcvr\n";
#print "<br>$doc\n";

#my $regexQuery = "$sndr\,$rcvr\,.*\,$date.*\,.*\,.*\,.*\,.*\,.*\,$doc\,";
my $regexQuery = "$sndr\,$rcvr\,.*\,.*\,.*\,.*\,.*\,.*\,.*\,$doc\,";
#my $regexQuery = "$sndr\,$rcvr\,.*\,.*,.*\,.*\,.*\,.*\,.*\,$doc\,";

# Filter items from CSV archive and output to temp csv file tmp/GUID.csv
$filteredFile = grepArchive($regexQuery,$id);

plotlyGen($id,$date,$chart);

}
# print HTML footer
print "</body></html>\n";

sub one_week_ago {
    my ($date_string) = @_;

    # Parse the input date
    my ($year, $month, $day) = split('-', $date_string);

    # Get the day of the week (0=Sunday, 1=Monday, etc.)
    my $day_of_week = (localtime(timelocal(0, 0, 0, $day, $month - 1, $year - 1900)))[6];

    # Subtract 1 week (604800 seconds)
    my $one_week_ago_timestamp = timelocal(0, 0, 0, $day - 7, $month - 1, $year - 1900);
    my $one_week_ago_day_of_week = (localtime($one_week_ago_timestamp))[6];

    # Check if the resulting date is the same day of the week
    if ($day_of_week == $one_week_ago_day_of_week) {
        my ($new_year, $new_month, $new_day) = (localtime($one_week_ago_timestamp))[5, 4, 3];
        $new_year += 1900;
        $new_month += 1;
        my $new_date_string = sprintf('%04d-%02d-%02d', $new_year, $new_month, $new_day);
        return $new_date_string;
    } else {
        return undef;
    }
}





################################################################################### SUBS





# Search for provided pattern within archive
sub grepArchive {
	use Data::GUID;

# Generate a new GUID
my $guid = Data::GUID->new();

# Print the GUID as a string
my $search_value = shift @_;
my $id = shift @_;
my $filename = "/home/dsp3930/nginx/tables/archive.csv";
open(FILTER,">/home/dsp3930/tmp/$id.csv");
#print "<br>$search_value\n";

open(my $fh, "<", $filename) or die "Can't open file: $!";
print FILTER "Interchange Sender,Interchange Receiver,Interchange Control Number,Interchange Timestamp,Group Sender,Group Receiver,Group Type,Group Control Number,Group Version,Message Type,Message Count,Message Segments,Content Size,Year,Month,Day,Week of Year,Day Name\n";
while (my $line = <$fh>) {
    chomp $line;
    if ($line =~ /$search_value/) {
        print FILTER "$line\n";
    }
}
return $id;

close $fh;
close(FILTER);
}


sub plotlyGen {
my $id = shift @_;
my $date = shift @_;
my $chart = shift @_;
# Execute python plotly program
if ($chart eq "Line")
{my $output = qx(/usr/bin/python3.9 /home/dsp3930/intdata/line.py $id $date);}
else
{print "<br>Invalid Chart Type: $chart\n";}
#print "<br> /home/dsp3930/intdata/today.py $id $date\n";
# Print the output to the console
open(FILE,"</home/dsp3930/tmp/$id.html")|| print "<br>File not found\n"; 
while ($x = <FILE>) {
print $x;
}
close(FILE);
#unlink("/home/dsp3930/tmp/$id.html");
}

sub testGen {
my $id = shift @_;
my $date = shift @_;
print "<br>$date\n";
}
