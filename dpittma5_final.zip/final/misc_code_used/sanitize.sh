#!/bin/sh
echo "Interchange Sender,Interchange Receiver,Interchange Control Number,Interchange Timestamp,Group Sender,Group Receiver,Group Type,Group Control Number,Group Version,Message Type,Message Count,Message Segments,Content Size,Year,Month,Day,Week of Year,Day Name" > archive.csv
./sanitize_csv.pl archive.txt >> archive.csv
