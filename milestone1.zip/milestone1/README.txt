March 18, 2023
 8H Reviewed Python+Ploty and worked with misc tests. This was to confirm I was comfortable with it and could generate reasonable results.
 This included: pie_messageCount.py  vbar_contentSize.py  vbar_messageCount.py  vbar_messageType.py
 Obtained an EDI archive from a period in 2009 for a client I worked with and created a Perl program (archiveInfo.pl) to process the data into csv format.
March 19, 2023
 4H Rreviewed concepts for CGI processing of user input 
 2H Created rough code for: gen_id_tables.sh (create key/value table for company names and IDs)
March 25, 2023
 2H Determined how to sanitize EDI addresses at the ISA and GS levels using stock ticker symbols.
 1H Ran some code generation qurries through ChatGPT to help find options that can be used for Python+Plotly and GGI 
April 8, 2023
 5H Built code to swap out addreses for EDI as determined on March 25 with sanitize_csv.pl and sanitize.sh


