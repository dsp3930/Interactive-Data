March 18, 2023
 8H Reviewed Python+Ploty and worked with misc tests. This was to confirm I was comfortable with it and could generate reasonable results. Then, generated project proposal.
 This included: pie_messageCount.py  vbar_contentSize.py  vbar_messageCount.py  vbar_messageType.py
 Obtained an EDI archive from a period in 2009 for a client I worked with and created a Perl program (archiveInfo.pl) to process the data into csv format.
March 19, 2023
 4H Rreviewed concepts for CGI processing of user input 
 2H Created rough code for: gen_id_tables.sh (create key/value table for company names and IDs)
March 25, 2023
 2H Determined how to sanitize EDI addresses at the ISA and GS levels using stock ticker symbols.
 1H Ran some code generation qurries through ChatGPT to help find options that can be used for Python+Plotly and GGI 
April 8, 2023
 5H Built code to swap out addreses for EDI as determined on March 25 with sanitize_csv.pl and sanitize.sh
 1H Wrote out Milestone 1 Detail for submission

Milestone 1 Detail:  

I began my project by reviewing Bokeh and Plotly/Plotly.express to determine which one I wanted to work with. I had previous expereince with Bokeh during our group project, but most of the class seemed to be leaning towards using plotly. I reviewed several places online with documentation on it. It definately seemed to be capable but also easier to understand and code with, so that is the python library I chose to use and detail out my project proposal with.

I installed the required python code on my GCP instance, created a Perl program to process my RAW EDI data into a CSV format suitable for use with Plotly. Then, I started working on some basic py scripts to make sure generation was workable for me to have acceptable output.

Later, I started to review how I would make this process interactive for the user via GGI.  At the current time, I plan to build an interactive GGI that selects the fields the user would be interested in seeing and then filter that from the archive.csv to generate the appropriate charts. I asked ChatGPT for some information GGI to refresh my memory on its use as it has been over 15 years since I last worked with it.

This weekend (4/8), I worked on getting the archive.txt file that still had company details in it sanitized. This was done by building a Perl program to swap out the fields for the stock ticker IDs from some of the Fortune 100. (a csv pulled form Kaggle)

As of now (Milestone 1), I now have a CSV that represents all the interchange details from the RAW EDI data I processed in my Perl program. This data is now ready for processing by my CGI (once developed) that I will be building out as the core functionality in MileStone 2.  

The process so far has not been too complex, just rather time consuming to make sure that I can deliver what I have committed to -- now at 23hrs of effort and review. I feel much better about using Plotly and working with Python. This part exceeded my expetations. The time to get to this point is more than I expected, but then agian I always seem to underestimate the time required to complete complex things. It has been interesting, so the good part is that the time required felt like it it passed quickly. 

I ran into a bit of a brain block working on the sanitizing program trying to figure out a bug for about an hour. That bug turned out to be missing values in the Fortune 500 csv for stock tickers, which was causing blanks to show up in a few areas of my archive.csv file. I removed those companies from the Fortune 500 csv as those values were not relevent to my project and that resolved the issue.


