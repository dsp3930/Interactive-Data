import pandas as pd
from matplotlib import pyplot as plt
import plotly.express as px
import numpy as np

csv = pd.read_csv('archive.csv', header = 0)


csv_clean = csv.astype({'Direction': 'category','Interchange Sender': 'category','Interchange Receiver': 'category','Group Sender': 'category','Group Receiver': 'category','Group Type': 'category','Group Version': 'category','Message Type': 'category'})
fig = px.pie(csv_clean, values="Message Count", names="Message Type", title='Message Count By Document Type')
fig.write_html("test.html")
