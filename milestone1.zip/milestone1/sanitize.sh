#!/bin/sh
echo "Direction,Interchange Sender,Interchange Receiver,Interchange Control Number,Interchange Date,Interchange Timestamp,Group Sender,Group Receiver,Group Type,Group Control Number,Group Version,Message Type,Message Count,Message Segments,Content Size" > archive.csv
./sanitize_csv.pl archive.txt >> archive.csv
