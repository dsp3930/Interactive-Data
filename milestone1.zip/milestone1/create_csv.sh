#!/bin/sh
#ls -1rt archive/out/*|while read x; do ./archiveInfo.pl Out $x; done >> archive.tmp
ls -1rt archive/in/*|while read x; do ./archiveInfo.pl $x; done > archive.tmp

#echo "Direction,Interchange Sender,Interchange Receiver,Interchange Control Number,Interchange Timestamp,Group Sender,Group Receiver,Group Type,Group Control Number,Group Version,Message Type,Message Count,Message Segments,Content Size" > archive.csv
cat archive.tmp |sort -t , -k +4 > archive.txt
